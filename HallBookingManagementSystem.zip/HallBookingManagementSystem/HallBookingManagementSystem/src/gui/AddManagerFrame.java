package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import utils.FileManager;

public class AddManagerFrame extends JFrame {
    public AddManagerFrame(String adminName) {
        setTitle("Add Manager");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JPasswordField confirmPasswordField = new JPasswordField();
        JButton addBtn = new JButton("Add Manager");
        JButton backBtn = new JButton("Back");

        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Confirm Password:"));
        panel.add(confirmPasswordField);
        panel.add(new JLabel(""));
        panel.add(addBtn);
        panel.add(new JLabel(""));
        panel.add(backBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);

        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }
                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match.");
                    return;
                }
                if (!email.contains("@") || !email.contains(".")) {
                    JOptionPane.showMessageDialog(null, "Invalid email format.");
                    return;
                }
                List<String> users = FileManager.readFile("users.txt");
                for (String line : users) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 3 && parts[2].equalsIgnoreCase(email)) {
                        JOptionPane.showMessageDialog(null, "Email already registered.");
                        return;
                    }
                }
                // Generate next sequential manager ID
                int max = 0;
                for (String uline : users) {
                    String[] uparts = uline.split("\\|");
                    if (uparts.length > 0 && uparts[0].startsWith("MAN")) {
                        try {
                            int num = Integer.parseInt(uparts[0].substring(3));
                            if (num > max) max = num;
                        } catch (NumberFormatException ignored) {}
                    }
                }
                String userId = String.format("MAN%03d", max + 1);
                String line = userId + "|Manager|" + email + "|" + password + "|" + name;
                FileManager.writeToFile("users.txt", line);
                JOptionPane.showMessageDialog(null, "Manager added successfully!");
                dispose();
                new AdminDashboard(adminName);
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new AdminDashboard(adminName);
            }
        });
        setVisible(true);
    }
}
