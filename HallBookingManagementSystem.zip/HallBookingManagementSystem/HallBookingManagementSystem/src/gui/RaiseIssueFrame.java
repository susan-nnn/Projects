package gui;

import javax.swing.*;
import java.util.List;
import java.awt.*;

import java.util.UUID;
import utils.FileManager;

public class RaiseIssueFrame extends JFrame {

    public RaiseIssueFrame(String customerId) {
        setTitle("Raise Issue");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));

        JTextField hallIdField = new JTextField();
        JTextArea issueArea = new JTextArea();
        JButton submitBtn = new JButton("Submit");

        panel.add(new JLabel("Hall ID:"));
        panel.add(hallIdField);

        panel.add(new JLabel("Describe the issue:"));
        panel.add(new JScrollPane(issueArea));

        panel.add(new JLabel(""));
        panel.add(submitBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        submitBtn.addActionListener(_ -> {
            String hallId = hallIdField.getText().trim();
            String description = issueArea.getText().trim();
            if (hallId.isEmpty() || description.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                return;
            }

            // Generate next sequential issue ID
            List<String> issueLines = FileManager.readFile("issues.txt");
            int maxId = 0;
            for (String l : issueLines) {
                String[] d = l.split("\\|");
                if (d.length > 0 && d[0].startsWith("ISS")) {
                    try {
                        int num = Integer.parseInt(d[0].substring(3));
                        if (num > maxId) maxId = num;
                    } catch (Exception ex) {}
                }
            }
            String issueId = String.format("ISS%03d", maxId + 1);
            String scheduler = "";
            String response = "";
            String line = issueId + "|" + customerId + "|" + hallId + "|" + description + "|Pending|" + scheduler + "|" + response;

            FileManager.writeToFile("issues.txt", line);
            JOptionPane.showMessageDialog(null, "Issue submitted! ID: " + issueId);
            dispose();
        });
    }
}