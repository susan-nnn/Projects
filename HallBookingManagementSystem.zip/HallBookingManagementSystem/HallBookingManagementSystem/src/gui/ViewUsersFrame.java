package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import utils.FileManager;

public class ViewUsersFrame extends JFrame {
    public ViewUsersFrame(String adminName) {
        setTitle("View Users");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnNames = {"UserID", "Role", "Email", "Name"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        add(panel, BorderLayout.CENTER);

        String userFilePath = System.getProperty("user.dir") + java.io.File.separator + "users.txt";
        
        List<String> users = FileManager.readFile(userFilePath);
        
        
        boolean isFirstLine = true;
        for (String line : users) {
            if (isFirstLine) { // Skip the header
                isFirstLine = false;
                continue;
            }
            String[] parts = line.split("\\|");
            if (parts.length >= 5 && !parts[1].equalsIgnoreCase("Admin") && !parts[1].equalsIgnoreCase("Administrator")) {
                model.addRow(new String[]{parts[0], parts[1], parts[2], parts[4]});
            }
        }

        JPanel buttonPanel = new JPanel();
        JButton blockBtn = new JButton("Block/Delete Selected");
        JButton backBtn = new JButton("Back");
        buttonPanel.add(blockBtn);
        buttonPanel.add(backBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        blockBtn.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(null, "Please select a user to block/delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to block/delete this user?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String userId = (String) model.getValueAt(row, 0);
            List<String> updated = new ArrayList<>();
            List<String> users;
            try {
                users = FileManager.readFile("users.txt");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error reading users file: " + ex.getMessage());
                return;
            }
            for (String line : users) {
                if (!line.startsWith(userId + "|")) {
                    updated.add(line);
                }
            }
            try {
                FileManager.overwriteFile("users.txt", updated);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error updating users file: " + ex.getMessage());
                return;
            }
            model.removeRow(row);
            JOptionPane.showMessageDialog(null, "User blocked/deleted.");
        }
    }
});

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new AdminDashboard(adminName);
            }
        });
        setVisible(true);
    }
    

    
} 