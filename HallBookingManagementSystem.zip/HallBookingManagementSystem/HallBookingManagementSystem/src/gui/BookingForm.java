package gui;

import javax.swing.*;
import java.awt.*;


import utils.FileManager;
import java.util.UUID;

public class BookingForm extends JFrame {

    public BookingForm(String customerId) {
        setTitle("Book a Hall");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

        JTextField hallIdField = new JTextField();
        JTextField dateField = new JTextField("yyyy-MM-dd");
        JTextField hoursField = new JTextField();
        JTextField rateField = new JTextField("Rate per hour");
        
        JLabel totalLabel = new JLabel("Total: ");
        JButton calculateBtn = new JButton("Calculate");
        JButton bookBtn = new JButton("Book");

        panel.add(new JLabel("Hall ID:"));
        panel.add(hallIdField);

        panel.add(new JLabel("Date & Time:"));
        panel.add(dateField);

        panel.add(new JLabel("Number of Hours (1-10):"));
        panel.add(hoursField);

        panel.add(new JLabel("Rate:"));
        panel.add(rateField);

        panel.add(calculateBtn);
        panel.add(totalLabel);

        panel.add(new JLabel(""));
        panel.add(bookBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        
        calculateBtn.addActionListener(_ -> {
            try {
                double rate = Double.parseDouble(rateField.getText());
                String hoursStr = hoursField.getText().trim();
                if (hoursStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter number of hours.");
                    return;
                }
                int hours = 0;
                try {
                    hours = Integer.parseInt(hoursStr);
                    if (hours < 1 || hours > 10) {
                        JOptionPane.showMessageDialog(this, "Hours must be between 1 and 10.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid number for hours.");
                    return;
                }
                double total = rate * hours;
                totalLabel.setText("Total: " + total);
            } catch (Exception ex) {
                totalLabel.setText("Invalid input!");
            }
        });

        
        bookBtn.addActionListener(_ -> {
            String bookingId = UUID.randomUUID().toString().substring(0, 6);
            String hallId = hallIdField.getText();
            String dateTime = dateField.getText();
            String hoursStr = hoursField.getText().trim();
            if (hoursStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter number of hours.");
                return;
            }
            int hours = 0;
            try {
                hours = Integer.parseInt(hoursStr);
                if (hours < 1 || hours > 10) {
                    JOptionPane.showMessageDialog(this, "Hours must be between 1 and 10.");
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number for hours.");
                return;
            }
            double rate = Double.parseDouble(rateField.getText());
            double total = rate * hours;
            String line = bookingId + "|" + hallId + "|" + customerId + "|" + dateTime + "|" + total + "|Confirmed";

            FileManager.writeToFile("bookings.txt", line);
            JOptionPane.showMessageDialog(null, "Hall booked! Booking ID: " + bookingId);
            dispose();
        });
    }

    public static void main(String[] args) {
        new BookingForm("CUS001");
    }
}