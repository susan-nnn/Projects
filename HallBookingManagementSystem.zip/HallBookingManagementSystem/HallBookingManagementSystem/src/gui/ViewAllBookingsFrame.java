package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import utils.FileManager;

public class ViewAllBookingsFrame extends JFrame {
    public ViewAllBookingsFrame(String adminName) {
        setTitle("All Bookings");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnNames = {"BookingID", "HallID", "CustomerID", "Date", "Amount", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setBorder(null);
        tableScrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // --- Add filter and search UI ---
        String[] filters = {"All", "Upcoming", "Past"};
        JComboBox<String> filterBox = new JComboBox<>(filters);
        JTextField searchField = new JTextField(16);
        JButton backBtn = new JButton("Back");
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Filter:"));
        topPanel.add(filterBox);
        topPanel.add(new JLabel("Search (ID/Customer):"));
        topPanel.add(searchField);
        topPanel.add(backBtn);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);

        // Define date formatter and get today's date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate today = LocalDate.now();

        // Helper to load bookings by filter and search
        Runnable loadTable = new Runnable() {
            public void run() {
                // Clear table
                model.setRowCount(0);
                // Always reload bookings from file with error handling
                List<String> bookings;
                try {
                    bookings = FileManager.readFile("bookings.txt");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error reading bookings file: " + ex.getMessage());
                    bookings = new ArrayList<>();
                }
                // Get selected filter and search text
                String filter = (String) filterBox.getSelectedItem();
                String search = searchField.getText().trim().toLowerCase();
                for (String line : bookings) {
                    String[] data = line.split("\\|");
                    if (data.length >= 6) {
                        String dateStr = data[3];
                        LocalDate bookingDate;
                        try {
                            bookingDate = LocalDate.parse(dateStr, formatter);
                        } catch (Exception ex) {
                            bookingDate = null;
                        }
                        boolean add = true;
                        // --- Filter by date ---
                        if (bookingDate != null) {
                            if (filter.equals("Upcoming") && !bookingDate.isAfter(today.minusDays(1))) add = false;
                            if (filter.equals("Past") && !bookingDate.isBefore(today)) add = false;
                        }
                        // --- Filter by search (BookingID, HallID, CustomerID) ---
                        if (!search.isEmpty()) {
                            // Search in BookingID, HallID, or CustomerID or Customer Name
                            if (!(data[0].toLowerCase().contains(search) || data[1].toLowerCase().contains(search) || data[2].toLowerCase().contains(search))) {
                                add = false;
                            }
                        }
                        if (add) {
                            model.addRow(new String[]{data[0], data[1], data[2], data[3], data[4], data[5]});
                        }
                    }
                }
            }
        };

        // Initial load
        loadTable.run();

        // --- Refresh table on filter change ---
        filterBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadTable.run();
            }
        });

        // --- Refresh table on search field change ---
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                loadTable.run();
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new AdminDashboard(adminName);
            }
        });
        setVisible(true);
    }

    public static void main(String[] args) {
        new ViewAllBookingsFrame("Admin");
    }
} 