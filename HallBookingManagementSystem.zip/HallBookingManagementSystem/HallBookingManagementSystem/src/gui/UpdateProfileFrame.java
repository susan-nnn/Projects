package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import utils.FileManager;

public class UpdateProfileFrame extends JFrame {
    public UpdateProfileFrame(String customerName) {
        setTitle("Update Profile");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

        JTextField nameField = new JTextField(customerName);
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton updateBtn = new JButton("Update");
        JButton backBtn = new JButton("Back");

        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(updateBtn);
        panel.add(backBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        updateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String newName = nameField.getText().trim();
                String newEmail = emailField.getText().trim();
                String newPassword = new String(passwordField.getPassword());

                if (newName.isEmpty() || newEmail.isEmpty() || newPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }
                if (!newEmail.contains("@") || !newEmail.contains(".")) {
                    JOptionPane.showMessageDialog(null, "Invalid email format.");
                    return;
                }
                List<String> users = FileManager.readFile("users.txt");
                List<String> updated = new ArrayList<>();
                boolean found = false;
                for (String line : users) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 5 && parts[4].equals(customerName)) {
                        // Update this user's info
                        String newLine = parts[0] + "|" + parts[1] + "|" + newEmail + "|" + newPassword + "|" + newName;
                        updated.add(newLine);
                        found = true;
                    } else {
                        updated.add(line);
                    }
                }
                if (found) {
                    FileManager.overwriteFile("users.txt", updated);
                    JOptionPane.showMessageDialog(UpdateProfileFrame.this, "Profile updated successfully!");
                    dispose();
                    new LoginFrame();
                } else {
                    JOptionPane.showMessageDialog(UpdateProfileFrame.this, "Profile not found.");
                }
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame();
            }
        });
    }

    public static void main(String[] args) {
        new UpdateProfileFrame("TestName");
    }
} 