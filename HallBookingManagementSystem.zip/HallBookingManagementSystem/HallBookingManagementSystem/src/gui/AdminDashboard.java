package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import utils.FileManager;

public class AdminDashboard extends JFrame {
    private JLabel statusLabel; // For status messages
    public AdminDashboard(String adminName) {
        setTitle("Admin Dashboard - Welcome " + adminName);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu bar with Help/About
        JMenuBar menuBar = new JMenuBar();
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
        aboutItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AboutDialog about = new AboutDialog(AdminDashboard.this);
                about.setVisible(true);
            }
        });

        JPanel panel = new JPanel(new GridLayout(9, 1, 10, 10));

        JButton addSchedulerBtn = new JButton("Add Scheduler Staff");
        JButton addCustomerBtn = new JButton("Add Customer");
        JButton addManagerBtn = new JButton("Add Manager");
        JButton viewSchedulerBtn = new JButton("View/Edit/Delete Scheduler Staff");
        JButton viewUsersBtn = new JButton("View/Block/Delete Users");
        JButton viewManagersBtn = new JButton("View Managers");
        JButton viewBookingsBtn = new JButton("View All Bookings");
        JButton logoutBtn = new JButton("Logout");

        addSchedulerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddSchedulerFrame(adminName);
            }
        });
        addCustomerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddCustomerFrame(adminName);
            }
        });
        addManagerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddManagerFrame(adminName);
            }
        });
        viewSchedulerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewSchedulerStaffFrame(adminName);
            }
        });
        viewUsersBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUsersFrame(adminName);
            }
        });
        viewManagersBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewManagersFrame(adminName);
            }
        });
        viewBookingsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewAllBookingsFrame(adminName);
            }
        });
        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame();
            }
        });

        panel.add(addSchedulerBtn);
        panel.add(addCustomerBtn);
        panel.add(addManagerBtn);
        panel.add(viewSchedulerBtn);
        panel.add(viewUsersBtn);
        panel.add(viewManagersBtn);
        panel.add(viewBookingsBtn);
        panel.add(logoutBtn);

        add(panel, BorderLayout.CENTER);
        // Status bar
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        add(statusLabel, BorderLayout.SOUTH);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);

        List<String> users = FileManager.readFile("users.txt");
        for (String line : users) {
            // Skip the header line if present
            if (line.startsWith("UserID|")) continue;
            String[] parts = line.split("\\|");
            if (parts.length >= 5 && parts[1].equalsIgnoreCase("Scheduler")) {
                
            }
        }

        setVisible(true);
    }


} 