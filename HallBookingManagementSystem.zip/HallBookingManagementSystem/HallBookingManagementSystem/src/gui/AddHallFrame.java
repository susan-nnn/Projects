package gui;

import javax.swing.*;
import java.awt.*;


public class AddHallFrame extends JFrame {

    // AddHallFrame allows the scheduler to add a new hall to the system
    public AddHallFrame(SchedulerDashboard parent) {
        setTitle("Add New Hall");
        setSize(600, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        //  Create panel with padding and background
        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(240, 248, 255)); // light blue background

        //  Bold font
        Font boldFont = new Font("Arial", Font.BOLD, 14);

        //  Title label
        JLabel title = new JLabel("Add New Hall");
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setHorizontalAlignment(JLabel.CENTER);

        //  Input fields
        JLabel idLabel = new JLabel("Hall ID:");
        idLabel.setFont(boldFont);
        JTextField hallIdField = new JTextField();
        hallIdField.setFont(boldFont);

        JLabel typeLabel = new JLabel("Hall Type:");
        typeLabel.setFont(boldFont);
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Banquet Hall", "Auditorium", "Meeting Room"});
        typeBox.setFont(boldFont);

        JLabel capLabel = new JLabel("Capacity:");
        capLabel.setFont(boldFont);
        JTextField capacityField = new JTextField();
        capacityField.setFont(boldFont);
        // Auto-fill capacity based on type
        typeBox.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String type = (String) typeBox.getSelectedItem();
                if (type.equalsIgnoreCase("Auditorium")) capacityField.setText("1000");
                else if (type.equalsIgnoreCase("Banquet Hall")) capacityField.setText("300");
                else if (type.equalsIgnoreCase("Meeting Room")) capacityField.setText("30");
            }
        });
        // Set initial value
        capacityField.setText("300");

        JLabel rateLabel = new JLabel("Rate per hour:");
        rateLabel.setFont(boldFont);
        JTextField rateField = new JTextField();
        rateField.setFont(boldFont);
        // Auto-fill rate based on type
        typeBox.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String type = (String) typeBox.getSelectedItem();
                if (type.equalsIgnoreCase("Auditorium")) {
                    capacityField.setText("1000");
                    rateField.setText("5000");
                } else if (type.equalsIgnoreCase("Banquet Hall")) {
                    capacityField.setText("300");
                    rateField.setText("2000");
                } else if (type.equalsIgnoreCase("Meeting Room")) {
                    capacityField.setText("30");
                    rateField.setText("500");
                }
            }
        });
        // Set initial values
        capacityField.setText("300");
        rateField.setText("2000");

        JLabel availableDatesLabel = new JLabel("Available Dates (comma separated):");
        availableDatesLabel.setFont(boldFont);
        JTextField availableDatesField = new JTextField();
        availableDatesField.setFont(boldFont);
        availableDatesField.setToolTipText("e.g. 07/25/2025,07/28/2025");

        JLabel maintenanceDatesLabel = new JLabel("Maintenance Dates (comma separated):");
        maintenanceDatesLabel.setFont(boldFont);
        JTextField maintenanceDatesField = new JTextField();
        maintenanceDatesField.setFont(boldFont);
        maintenanceDatesField.setToolTipText("e.g. 08/25/2025,09/01/2025");

        JButton addBtn = new JButton("Add Hall");
        addBtn.setFont(boldFont);
        addBtn.setBackground(new Color(0, 123, 255)); // blue button
        addBtn.setForeground(Color.WHITE); // white text

        // 👇 Layout assembly
        panel.add(title);
        panel.add(new JLabel("")); // spacing

        panel.add(idLabel);
        panel.add(hallIdField);

        panel.add(typeLabel);
        panel.add(typeBox);

        panel.add(capLabel);
        panel.add(capacityField);

        panel.add(rateLabel);
        panel.add(rateField);

        panel.add(availableDatesLabel);
        panel.add(availableDatesField);

        panel.add(maintenanceDatesLabel);
        panel.add(maintenanceDatesField);

        panel.add(new JLabel(""));
        panel.add(addBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        // Action listener
        addBtn.addActionListener(_ -> {
            // Generate next sequential hall ID
            java.util.List<String> allHalls = utils.FileManager.readFile("halls.txt");
            int maxHall = 0;
            for (String hline : allHalls) {
                String[] hparts = hline.split("\\|");
                if (hparts.length > 0 && hparts[0].startsWith("HAL")) {
                    try {
                        int num = Integer.parseInt(hparts[0].substring(3));
                        if (num > maxHall) maxHall = num;
                    } catch (NumberFormatException ignored) {}
                }
            }
            String hallId = String.format("HAL%03d", maxHall + 1);
            String hallType = (String) typeBox.getSelectedItem();
            String capacity = capacityField.getText().trim();
            String rate = rateField.getText().trim();
            String availableDates = availableDatesField.getText().trim();
            String maintenanceDates = maintenanceDatesField.getText().trim();

            // --- Input validation ---
            if (hallId.isEmpty() || capacity.isEmpty() || rate.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all fields.");
                return;
            }
            // Check numeric fields
            try {
                int cap = Integer.parseInt(capacity);
                double r = Double.parseDouble(rate);
                if (cap <= 0 || r <= 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Capacity and Rate must be positive numbers.");
                return;
            }
            // Check duplicate Hall ID
            java.util.List<String> halls = utils.FileManager.readFile("halls.txt");
            for (String line : halls) {
                String[] parts = line.split("\\|");
                if (parts.length >= 1 && parts[0].equalsIgnoreCase(hallId)) {
                    JOptionPane.showMessageDialog(null, "Hall ID already exists.");
                    return;
                }
            }

            String line = hallId + "|" + hallType + "|" + capacity + "|" + rate + "|" + availableDates + "|" + maintenanceDates;
            utils.FileManager.writeToFile("halls.txt", line);
            JOptionPane.showMessageDialog(null, "New hall added successfully!");
            dispose();
            if (parent != null) parent.reloadTable.run();
        });
    }

    // Default constructor for standalone testing
    public AddHallFrame() {
        this(null);
    }

    public static void main(String[] args) {
        new AddHallFrame();
    }
}