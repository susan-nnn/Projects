package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import utils.FileManager;

public class ViewBookingsFrame extends JFrame {

    public ViewBookingsFrame(String customerId) {
        setTitle("My Bookings");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnNames = {"Booking ID", "Hall ID", "Date", "Amount", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable bookingTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel filterPanel = new JPanel();
        JComboBox<String> filterBox = new JComboBox<>(new String[]{"All", "Upcoming", "Past"});
        JButton receiptBtn = new JButton("View Receipt");
        JTextField searchField = new JTextField(10);

        filterPanel.add(new JLabel("Show:"));
        filterPanel.add(filterBox);
        filterPanel.add(new JLabel("Search:"));
        filterPanel.add(searchField);
        filterPanel.add(receiptBtn);
        add(filterPanel, BorderLayout.NORTH);

        List<String> lines = FileManager.readFile("bookings.txt");

        // ✅ Use correct formatter
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        // Populate table with filter
        ActionListener populateTable = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                model.setRowCount(0);
                String selected = (String) filterBox.getSelectedItem();
                LocalDate today = LocalDate.now();

                for (String line : lines) {
                    String[] data = line.split("\\|");
                    if (data.length == 6 && data[1].equals(customerId)) {
                        try {
                            LocalDate bookDate = LocalDate.parse(data[3], formatter);
                            boolean add = true;

                            if ("Upcoming".equals(selected)) {
                                add = !bookDate.isBefore(today);
                            } else if ("Past".equals(selected)) {
                                add = bookDate.isBefore(today);
                            }

                            if (add) {
                                model.addRow(new String[]{
                                    data[0], data[2], data[3], "RM" + data[4], data[5]
                                });
                            }
                        } catch (Exception ex) {
                            System.err.println("Invalid date format in line: " + line);
                        }
                    }
                }
            }
        };
        filterBox.addActionListener(populateTable);
        populateTable.actionPerformed(null); // Initial load

        // Search filter
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String search = searchField.getText().trim().toLowerCase();
                model.setRowCount(0);
                String selected = (String) filterBox.getSelectedItem();
                LocalDate today = LocalDate.now();

                for (String line : lines) {
                    String[] data = line.split("\\|");
                    if (data.length == 6 && data[1].equals(customerId)) {
                        try {
                            LocalDate bookDate = LocalDate.parse(data[3], formatter);
                            boolean add = true;

                            if ("Upcoming".equals(selected)) {
                                add = !bookDate.isBefore(today);
                            } else if ("Past".equals(selected)) {
                                add = bookDate.isBefore(today);
                            }

                            boolean matchesSearch = data[0].toLowerCase().contains(search) ||
                                                    data[1].toLowerCase().contains(search);

                            if (add && matchesSearch) {
                                model.addRow(new String[]{
                                    data[0], data[2], data[3], "RM" + data[4], data[5]
                                });
                            }
                        } catch (Exception ex) {
                            System.err.println("Invalid date format in line: " + line);
                        }
                    }
                }
            }
        });

        // Receipt button
        receiptBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = bookingTable.getSelectedRow();
                if (row == -1) {
                    JOptionPane.showMessageDialog(ViewBookingsFrame.this, "Select a booking to view receipt.");
                    return;
                }

                String bookingId = (String) model.getValueAt(row, 0);
                String hallId = (String) model.getValueAt(row, 1);
                String date = (String) model.getValueAt(row, 2);
                String amount = (String) model.getValueAt(row, 3);
                String status = (String) model.getValueAt(row, 4);

                JOptionPane.showMessageDialog(ViewBookingsFrame.this,
                    "--- Booking Receipt ---\n" +
                    "Booking ID: " + bookingId + "\n" +
                    "Hall ID: " + hallId + "\n" +
                    "Date: " + date + "\n" +
                    "Amount: " + amount + "\n" +
                    "Status: " + status + "\n" +
                    "Thank you for booking!",
                    "Receipt", JOptionPane.INFORMATION_MESSAGE);

                utils.Logger.log("Viewed receipt for booking: " + bookingId);
            }
        });

        setVisible(true);
    }
}
