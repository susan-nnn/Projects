package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import utils.FileManager;

public class ManagerDashboard extends JFrame {

    private JTable salesTable, issueTable;
    private DefaultTableModel salesModel, issueModel;
    private JComboBox<String> filterBox;

    public ManagerDashboard() {
        setTitle("Manager Dashboard");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        JPanel salesPanel = createSalesPanel();
        JPanel issuePanel = createIssuePanel();

        tabs.addTab("Sales", salesPanel);
        tabs.addTab("Maintenance", issuePanel);

        add(tabs, BorderLayout.CENTER);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame();
            }
        });
        add(logoutBtn, BorderLayout.SOUTH);

        setVisible(true);
    }

     //---------------------- SALES PANEL ----------------------

    private JPanel createSalesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("Sales Dashboard", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Booking ID", "Customer ID", "Hall ID", "Hall Type", "Date", "Amount", "Status"};
        salesModel = new DefaultTableModel(columns, 0);
        salesTable = new JTable(salesModel);
        panel.add(new JScrollPane(salesTable), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton confirmBtn = new JButton("Confirm Booking");
        bottom.add(confirmBtn);

        filterBox = new JComboBox<>(new String[]{"All", "Weekly", "Monthly", "Yearly"});
        bottom.add(new JLabel("Filter:"));
        bottom.add(filterBox);

        // Revenue label
        JLabel revenueLabel = new JLabel("Total Revenue: RM 0.00");
        revenueLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(revenueLabel, BorderLayout.EAST);

        panel.add(bottom, BorderLayout.SOUTH);

        loadSalesData("All", revenueLabel);

        confirmBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                confirmSelectedBooking();
            }
        });

        filterBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String filter = (String) filterBox.getSelectedItem();
                loadSalesData(filter, revenueLabel);
            }
        });

        return panel;
    }

    private void loadSalesData(String filter, JLabel revenueLabel) {
        salesModel.setRowCount(0);  //Clear table
        List<String> lines = FileManager.readFile("bookings.txt");
        double totalRevenue = 0.0;
        // Load hall types into a map for fast lookup
        List<String> hallLines = FileManager.readFile("halls.txt");
        Map<String, String> hallTypeMap = new HashMap<>();
        for (String hline : hallLines) {
            String[] hparts = hline.split("\\|");
            if (hparts.length >= 2) {
                hallTypeMap.put(hparts[0], hparts[1]);
            }
        }
        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts.length >= 6) {
                String date = parts[3];
                String hallType = hallTypeMap.getOrDefault(parts[2], "Unknown");
                // Only filter by date, not by status or hall
                if (shouldInclude(date, filter)) {
                    salesModel.addRow(new String[]{
                        parts[0], // Booking ID
                        parts[1], // Customer ID
                        parts[2], // Hall ID
                        hallType, // Hall Type
                        parts[3], // Date
                        parts[4], // Amount
                        parts[5]  // Status
                    });
                }
                // Only add CONFIRMED bookings to revenue
                if ("CONFIRMED".equalsIgnoreCase(parts[5])) {
                    try {
                        totalRevenue += Double.parseDouble(parts[4]);
                    } catch (NumberFormatException ex) {
                        // skip invalid
                    }
                }
            }
        }
        revenueLabel.setText(String.format("Total Revenue: RM %.2f", totalRevenue));
    }

    private void confirmSelectedBooking() {
        int row = salesTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking first.");
            return;
        }

        String bookingId = (String) salesModel.getValueAt(row, 0);
        String currentStatus = (String) salesModel.getValueAt(row, 6);

        if (!"PENDING".equalsIgnoreCase(currentStatus)) {
            JOptionPane.showMessageDialog(this, "Only PENDING bookings can be confirmed.");
            return;
        }

        List<String> lines = FileManager.readFile("bookings.txt");
        List<String> updated = new ArrayList<>();
        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts.length >= 6 && parts[0].equals(bookingId)) {
                parts[5] = "CONFIRMED";
                updated.add(String.join("|", parts));
            } else {
                updated.add(line);
            }
        }

        FileManager.overwriteFile("bookings.txt", updated);
        // Immediately reload table and revenue after confirming
        loadSalesData((String)filterBox.getSelectedItem(), (JLabel)((JPanel)((JTabbedPane)getContentPane().getComponent(0)).getComponentAt(0)).getComponent(2));
        JOptionPane.showMessageDialog(this, "Booking confirmed!");
    }

    private boolean shouldInclude(String dateStr, String filter) {
        java.time.LocalDate date = null;
        try {
            date = java.time.LocalDate.parse(dateStr);
        } catch (java.time.format.DateTimeParseException ex1) {
            try {
                java.time.format.DateTimeFormatter altFmt = java.time.format.DateTimeFormatter.ofPattern("MM/dd/yyyy");
                date = java.time.LocalDate.parse(dateStr, altFmt);
            } catch (java.time.format.DateTimeParseException ex2) {
                return false; // skip invalid date
            }
        }
        java.time.LocalDate today = java.time.LocalDate.now();

        switch (filter) {
            case "Weekly":
                java.time.temporal.WeekFields weekFields = java.time.temporal.WeekFields.of(Locale.getDefault());
                return date.getYear() == today.getYear() &&
                        date.get(weekFields.weekOfWeekBasedYear()) == today.get(weekFields.weekOfWeekBasedYear());
            case "Monthly":
                return date.getYear() == today.getYear() && date.getMonthValue() == today.getMonthValue();
            case "Yearly":
                return date.getYear() == today.getYear();
            default:
                return true;
        }
    }

     //---------------------- ISSUE PANEL ----------------------

    private JPanel createIssuePanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("Maintenance Issues", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        String[] columns = {"Issue ID", "Customer ID", "Hall ID", "Description", "Status", "Scheduler", "Response"};
        issueModel = new DefaultTableModel(columns, 0);
        issueTable = new JTable(issueModel);
        panel.add(new JScrollPane(issueTable), BorderLayout.CENTER);

        loadIssueData();

        JPanel controlPanel = new JPanel();
        JTextField issueIdField = new JTextField(5);
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"In progress", "Done", "Closed", "Cancelled"});
        JComboBox<String> schedulerBox = new JComboBox<>();
        JTextField responseField = new JTextField(10);
        JButton updateBtn = new JButton("Update");

         //Load schedulers
        for (String line : FileManager.readFile("users.txt")) {
            String[] parts = line.split("\\|");
            if (parts.length >= 2 && parts[1].equalsIgnoreCase("Scheduler")) {
                schedulerBox.addItem(parts[0]);
            }
        }

        controlPanel.add(new JLabel("Issue ID:"));
        controlPanel.add(issueIdField);
        controlPanel.add(new JLabel("Status:"));
        controlPanel.add(statusBox);
        controlPanel.add(new JLabel("Scheduler:"));
        controlPanel.add(schedulerBox);
        controlPanel.add(new JLabel("Response:"));
        controlPanel.add(responseField);
        controlPanel.add(updateBtn);

        updateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateIssue(issueIdField.getText().trim(), (String) statusBox.getSelectedItem(),
                        (String) schedulerBox.getSelectedItem(), responseField.getText().trim());
            }
        });

        panel.add(controlPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadIssueData() {
        List<String> lines = FileManager.readFile("issues.txt");
        for (String line : lines) {
            String[] parts = line.split("\\|");
            String[] row = new String[7];
            for (int i = 0; i < 7; i++) {
                row[i] = (i < parts.length) ? parts[i] : "";
            }
            issueModel.addRow(row);
        }
    }

    private void updateIssue(String issueId, String status, String scheduler, String response) {
        List<String> lines = FileManager.readFile("issues.txt");
        List<String> updated = new ArrayList<>();
        boolean found = false;

        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts.length < 7) {
                parts = Arrays.copyOf(parts, 7);
                for (int i = 0; i < 7; i++) {
                    if (parts[i] == null) parts[i] = "";
                }
            }
            if (parts[0].equals(issueId)) {
                parts[4] = status;
                parts[5] = scheduler;
                parts[6] = response;
                found = true;
            }
            updated.add(String.join("|", parts));
        }

        if (found) {
            FileManager.overwriteFile("issues.txt", updated);
            JOptionPane.showMessageDialog(this, "Issue updated!");
            // Reload issue table in place
            issueModel.setRowCount(0);
            loadIssueData();
        } else {
            JOptionPane.showMessageDialog(this, "Issue ID not found.");
        }
    }

    public static void main(String[] args) {
        new ManagerDashboard();
    }
}
