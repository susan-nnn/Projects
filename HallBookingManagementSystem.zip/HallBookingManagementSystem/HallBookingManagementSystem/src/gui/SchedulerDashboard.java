package gui;

import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import utils.FileManager;

public class SchedulerDashboard extends JFrame {

    public Runnable reloadTable;

    public SchedulerDashboard(String schedulerId) {
        setTitle("Scheduler Control Panel");
        setSize(600, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());    //Explicit layout

         //--- Search/Filter Panel ---
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search Hall:"));
        JTextField searchField = new JTextField(15);
        searchPanel.add(searchField);
        JButton searchBtn = new JButton("Search");
        searchPanel.add(searchBtn);
        JButton refreshBtn = new JButton("Refresh");
        searchPanel.add(refreshBtn);
        JButton addHallBtn = new JButton("Add New Hall");
        searchPanel.add(addHallBtn);
        JButton backBtn = new JButton("Back");
        searchPanel.add(backBtn);
        JButton logoutBtn = new JButton("Logout");
        searchPanel.add(logoutBtn);
        add(searchPanel, BorderLayout.NORTH);    //placed in NORTH

         //--- Table & Scroll ---
        String[] columns = {"Hall ID", "Type", "Capacity", "Rate", "Available Dates", "Maintenance Dates"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable hallTable = new JTable(model);
        hallTable.setFillsViewportHeight(true);  
        JScrollPane scrollPane = new JScrollPane(hallTable);
        add(scrollPane, BorderLayout.CENTER);    //placed in CENTER

         //--- Buttons Panel (Edit/Delete) ---
        JPanel crudPanel = new JPanel();
        JButton editBtn = new JButton("Edit Selected");
        JButton deleteBtn = new JButton("Delete Selected");
        crudPanel.add(editBtn);
        crudPanel.add(deleteBtn);
        add(crudPanel, BorderLayout.SOUTH);    //placed in SOUTH

         //--- Load table data ---
        Runnable loadTable = () -> {
            model.setRowCount(0);
            List<String> halls = FileManager.readFile("halls.txt");
            String search = searchField.getText().trim().toLowerCase();
            for (String line : halls) {
                String[] data = line.split("\\|");
                if (data.length == 6) {
                    boolean add = true;
                    if (!search.isEmpty()) {
                        add = false;
                        for (String d : data)
                            if (d.toLowerCase().contains(search)) add = true;
                    }
                    if (add) model.addRow(data);
                }
            }
        };
        loadTable.run();
        this.reloadTable = loadTable;

         //--- Search Functionality ---
        searchBtn.addActionListener(_ -> loadTable.run());
        refreshBtn.addActionListener(_ -> {
            searchField.setText("");
            loadTable.run();
        });
        searchField.addActionListener(_ -> loadTable.run());

         //--- Add New Hall ---
        addHallBtn.addActionListener(_ -> new AddHallFrame(this));

         //--- Edit Hall ---
        editBtn.addActionListener(_ -> {
            int row = hallTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a hall to edit.");
                return;
            }
            String[] data = new String[6];
            for (int i = 0; i < 6; i++) data[i] = (String) model.getValueAt(row, i);
            new EditHallFrame(this, data);
        });

         //--- Delete Hall ---
        deleteBtn.addActionListener(_ -> {
            int row = hallTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a hall to delete.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this hall?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            String hallId = (String) model.getValueAt(row, 0);
            List<String> halls = FileManager.readFile("halls.txt");
            List<String> updated = new ArrayList<>();
            for (String line : halls) {
                String[] parts = line.split("\\|");
                if (parts.length == 6 && parts[0].equals(hallId)) continue;
                updated.add(line);
            }
            FileManager.overwriteFile("halls.txt", updated);
            JOptionPane.showMessageDialog(this, "Hall deleted.");
            loadTable.run();
        });

         //--- Double-click to open scheduling ---
        hallTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = hallTable.getSelectedRow();
                    if (row != -1) {
                        String[] data = new String[6];
                        for (int i = 0; i < 6; i++) data[i] = (String) model.getValueAt(row, i);
                        new ScheduleFrame(SchedulerDashboard.this, data);
                    }
                }
            }
        });

         //--- Back & Logout ---
        backBtn.addActionListener(_ -> {
            dispose();
            new LoginFrame();
        });

        logoutBtn.addActionListener(_ -> {
            dispose();
            new LoginFrame();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new SchedulerDashboard("SCH001");
    }
}
