package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import utils.FileManager;

public class ViewManagersFrame extends JFrame {
    private DefaultTableModel model;
    private JTable table;

    public ViewManagersFrame(String adminName) {
        setTitle("View Managers");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(new String[]{"User ID", "Name", "Email"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadManagers();

        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(_ -> {
            dispose();
            new AdminDashboard(adminName);
        });
        JPanel btnPanel = new JPanel();
        btnPanel.add(backBtn);
        add(btnPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadManagers() {
        model.setRowCount(0);
        List<String> users = FileManager.readFile("users.txt");
        for (String line : users) {
            if (line.startsWith("UserID|")) continue;
            String[] parts = line.split("\\|");
            if (parts.length >= 5 && parts[1].equalsIgnoreCase("Manager")) {
                model.addRow(new Object[]{parts[0], parts[4], parts[2]});
            }
        }
    }
}
