package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;







/**
 * ScheduleFrame allows the scheduler to set availability or maintenance for a hall.
 */
public class ScheduleFrame extends JFrame {
    /**
     * ScheduleFrame allows the scheduler to set availability or maintenance for a hall.
     * @param parent Reference to SchedulerDashboard for table refresh
     * @param hallData Array of hall details: [ID, Type, Capacity, Rate, AvailDates, MaintDates]
     */
    public ScheduleFrame(SchedulerDashboard parent, String[] hallData) {
        // Set the title of the frame
        setTitle("Schedule Hall Availability/Maintenance");
        setSize(600, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(245, 255, 250));
        Font boldFont = new Font("Arial", Font.BOLD, 14);

        JLabel title = new JLabel("Schedule for Hall: " + hallData[0]);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setHorizontalAlignment(JLabel.CENTER);

        // --- Show existing schedules ---
        // These text areas show the current schedules for this hall (read from the hallData array)
        JLabel existingAvailLabel = new JLabel("Existing Availability Schedules:");
        existingAvailLabel.setFont(boldFont);
        JTextArea existingAvailArea = new JTextArea(hallData[4] == null || hallData[4].isEmpty() ? "(None)" : hallData[4]);
        existingAvailArea.setEditable(false);
        existingAvailArea.setLineWrap(true);
        existingAvailArea.setWrapStyleWord(true);
        JScrollPane availScroll = new JScrollPane(existingAvailArea);
        availScroll.setPreferredSize(new Dimension(200, 40));

        JLabel existingMaintLabel = new JLabel("Existing Maintenance Schedules:");
        existingMaintLabel.setFont(boldFont);
        JTextArea existingMaintArea = new JTextArea(hallData[5] == null || hallData[5].isEmpty() ? "(None)" : hallData[5]);
        existingMaintArea.setEditable(false);
        existingMaintArea.setLineWrap(true);
        existingMaintArea.setWrapStyleWord(true);
        JScrollPane maintScroll = new JScrollPane(existingMaintArea);
        maintScroll.setPreferredSize(new Dimension(200, 40));

        // --- Availability ---
        JLabel availLabel = new JLabel("Set Availability:");
        availLabel.setFont(boldFont);
        JLabel availStartLabel = new JLabel("Start DateTime (yyyy-MM-dd HH:mm):");
        availStartLabel.setFont(boldFont);
        JTextField availStartField = new JTextField();
        availStartField.setFont(boldFont);
        availStartField.setToolTipText("2025-07-25 14:00");
        JLabel availEndLabel = new JLabel("End DateTime (yyyy-MM-dd HH:mm):");
        availEndLabel.setFont(boldFont);
        JTextField availEndField = new JTextField();
        availEndField.setFont(boldFont);
        availEndField.setToolTipText("2025-07-25 18:00");
        JLabel availRemarksLabel = new JLabel("Availability Remarks:");
        availRemarksLabel.setFont(boldFont);
        JTextField availRemarksField = new JTextField();
        availRemarksField.setFont(boldFont);
        availRemarksField.setToolTipText("e.g. Hall reserved for July Conference");
        JButton addAvailBtn = new JButton("Add Availability");

        // --- Maintenance ---
        JLabel maintLabel = new JLabel("Set Maintenance:");
        maintLabel.setFont(boldFont);
        JLabel maintStartLabel = new JLabel("Start DateTime (yyyy-MM-dd HH:mm):");
        maintStartLabel.setFont(boldFont);
        JTextField maintStartField = new JTextField();
        maintStartField.setFont(boldFont);
        maintStartField.setToolTipText("e.g. 2025-08-01 09:00");
        JLabel maintEndLabel = new JLabel("End DateTime (yyyy-MM-dd HH:mm):");
        maintEndLabel.setFont(boldFont);
        JTextField maintEndField = new JTextField();
        maintEndField.setFont(boldFont);
        maintEndField.setToolTipText("e.g. 2025-08-01 16:00");
        JLabel maintRemarksLabel = new JLabel("Maintenance Remarks:");
        maintRemarksLabel.setFont(boldFont);
        JTextField maintRemarksField = new JTextField();
        maintRemarksField.setFont(boldFont);
        maintRemarksField.setToolTipText("e.g. Air conditioning check and lighting repairs");
        JButton addMaintBtn = new JButton("Add Maintenance");

        // --- Layout ---
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Existing Schedules Panel
        JPanel existingPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        existingPanel.setBorder(BorderFactory.createTitledBorder("Existing Schedules"));
        existingPanel.add(existingAvailLabel); existingPanel.add(availScroll);
        existingPanel.add(existingMaintLabel); existingPanel.add(maintScroll);
        panel.add(existingPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Availability Section
        JPanel availPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        availPanel.setBorder(BorderFactory.createTitledBorder("Set Availability"));
        availPanel.add(availStartLabel); availPanel.add(availStartField);
        availPanel.add(availEndLabel); availPanel.add(availEndField);
        availPanel.add(availRemarksLabel); availPanel.add(availRemarksField);
        availPanel.add(new JLabel()); availPanel.add(addAvailBtn);
        panel.add(availPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Maintenance Section
        JPanel maintPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        maintPanel.setBorder(BorderFactory.createTitledBorder("Set Maintenance"));
        maintPanel.add(maintStartLabel); maintPanel.add(maintStartField);
        maintPanel.add(maintEndLabel); maintPanel.add(maintEndField);
        maintPanel.add(maintRemarksLabel); maintPanel.add(maintRemarksField);
        maintPanel.add(new JLabel()); maintPanel.add(addMaintBtn);
        panel.add(maintPanel);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        // --- Add Availability Logic ---
        // When the "Add Availability" button is clicked, this code runs
        addAvailBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the values entered by the user
                String start = availStartField.getText().trim();
                String end = availEndField.getText().trim();
                String remarks = availRemarksField.getText().trim();

                // Check if start and end are entered
                if (start.isEmpty() || end.isEmpty()) {
                    JOptionPane.showMessageDialog(ScheduleFrame.this, "Please enter start and end date/time for availability.");
                    return;
                }
                // Check if the date/time format is correct
                if (!start.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}") || !end.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
                    JOptionPane.showMessageDialog(ScheduleFrame.this, "Date/time must be in yyyy-MM-dd HH:mm format.");
                    return;
                }
                // Prepare the string to add to the file
                String entry = start + " to " + end + (remarks.isEmpty() ? "" : " (" + remarks + ")");
                // Read the halls.txt file (each line is a hall)
                java.util.List<String> halls = utils.FileManager.readFile("halls.txt");
                java.util.List<String> updated = new java.util.ArrayList<>();
                // Go through each line and update the correct hall
                for (int i = 0; i < halls.size(); i++) {
                    String line = halls.get(i);
                    String[] parts = line.split("\\|");
                    // If this is the hall we are updating
                    if (parts.length == 6 && parts[0].equalsIgnoreCase(hallData[0])) {
                        if (!parts[4].isEmpty()) parts[4] += ", ";
                        parts[4] += entry;
                        line = parts[0] + "|" + parts[1] + "|" + parts[2] + "|" + parts[3] + "|" + parts[4] + "|" + parts[5];
                    }
                    updated.add(line);
                }
                // Write the updated list back to the file
                utils.FileManager.overwriteFile("halls.txt", updated);
                JOptionPane.showMessageDialog(ScheduleFrame.this, "Availability added!");
                if (parent != null) parent.reloadTable.run();
                dispose();
            }
        });

        // --- Add Maintenance Logic ---
    
        // When the "Add Maintenance" button is clicked, this code runs
        addMaintBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the values entered by the user
                String start = maintStartField.getText().trim();
                String end = maintEndField.getText().trim();
                String remarks = maintRemarksField.getText().trim();

                // Check if start and end are entered
                if (start.isEmpty() || end.isEmpty()) {
                    JOptionPane.showMessageDialog(ScheduleFrame.this, "Please enter start and end date/time for maintenance.");
                    return;
                }
                // Check if the date/time format is correct
                if (!start.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}") || !end.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
                    JOptionPane.showMessageDialog(ScheduleFrame.this, "Date/time must be in yyyy-MM-dd HH:mm format.");
                    return;
                }
                // Prepare the string to add to the file
                String entry = start + " to " + end + (remarks.isEmpty() ? "" : " (" + remarks + ")");
                // Read the halls.txt file (each line is a hall)
                java.util.List<String> halls = utils.FileManager.readFile("halls.txt");
                java.util.List<String> updated = new java.util.ArrayList<>();
                // Go through each line and update the correct hall
                for (int i = 0; i < halls.size(); i++) {
                    String line = halls.get(i);
                    String[] parts = line.split("\\|");
                    // If this is the hall we are updating
                    if (parts.length == 6 && parts[0].equalsIgnoreCase(hallData[0])) {
                        if (!parts[5].isEmpty()) parts[5] += ", ";
                        parts[5] += entry;
                        line = parts[0] + "|" + parts[1] + "|" + parts[2] + "|" + parts[3] + "|" + parts[4] + "|" + parts[5];
                    }
                    updated.add(line);
                }
                // Write the updated list back to the file
                utils.FileManager.overwriteFile("halls.txt", updated);
                JOptionPane.showMessageDialog(ScheduleFrame.this, "Maintenance scheduled!");
                if (parent != null) parent.reloadTable.run();
                dispose();
            }
        });
    }
}
