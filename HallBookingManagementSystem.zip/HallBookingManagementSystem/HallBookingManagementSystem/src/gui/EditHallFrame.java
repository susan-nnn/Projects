package gui;

import javax.swing.*;
import java.awt.*;



/**
 * EditHallFrame allows the scheduler to edit an existing hall's details.
 * This is a stub to resolve missing class issues. Implementation needed.
 */
public class EditHallFrame extends JFrame {
    /**
     * EditHallFrame allows the scheduler to edit an existing hall's details.
     * @param parent Reference to SchedulerDashboard for table refresh
     * @param hallData Array of hall details: [ID, Type, Capacity, Rate, AvailDates, MaintDates]
     */
    public EditHallFrame(SchedulerDashboard parent, String[] hallData) {
        setTitle("Edit Hall");
        setSize(500, 400);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(255, 250, 240)); // light background
        Font boldFont = new Font("Arial", Font.BOLD, 14);

        JLabel title = new JLabel("Edit Hall");
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setHorizontalAlignment(JLabel.CENTER);

        // Fields
        JLabel idLabel = new JLabel("Hall ID:");
        idLabel.setFont(boldFont);
        JTextField hallIdField = new JTextField(hallData[0]);
        hallIdField.setFont(boldFont);
        hallIdField.setEditable(false);

        JLabel typeLabel = new JLabel("Hall Type:");
        typeLabel.setFont(boldFont);
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Banquet", "Auditorium", "Meeting Room"});
        typeBox.setFont(boldFont);
        typeBox.setSelectedItem(hallData[1]);

        JLabel capLabel = new JLabel("Capacity:");
        capLabel.setFont(boldFont);
        JTextField capacityField = new JTextField(hallData[2]);
        capacityField.setFont(boldFont);

        JLabel rateLabel = new JLabel("Rate per hour:");
        rateLabel.setFont(boldFont);
        JTextField rateField = new JTextField(hallData[3]);
        rateField.setFont(boldFont);

        JButton saveBtn = new JButton("Save Changes");
        saveBtn.setFont(boldFont);
        saveBtn.setBackground(new Color(40, 167, 69)); // green
        saveBtn.setForeground(Color.WHITE);

        // Layout
        panel.add(title); panel.add(new JLabel(""));
        panel.add(idLabel); panel.add(hallIdField);
        panel.add(typeLabel); panel.add(typeBox);
        panel.add(capLabel); panel.add(capacityField);
        panel.add(rateLabel); panel.add(rateField);
        panel.add(new JLabel("")); panel.add(saveBtn);
        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        saveBtn.addActionListener(_ -> {
            String hallId = hallIdField.getText().trim();
            String hallType = (String) typeBox.getSelectedItem();
            String capacity = capacityField.getText().trim();
            String rate = rateField.getText().trim();

            // --- Input validation ---
            if (capacity.isEmpty() || rate.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all fields.");
                return;
            }
            try {
                int cap = Integer.parseInt(capacity);
                double r = Double.parseDouble(rate);
                if (cap <= 0 || r <= 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Capacity and Rate must be positive numbers.");
                return;
            }
            // --- Update halls.txt ---
            java.util.List<String> halls = utils.FileManager.readFile("halls.txt");
            java.util.List<String> updated = new java.util.ArrayList<>();
            for (String line : halls) {
                String[] parts = line.split("\\|");
                if (parts.length == 6 && parts[0].equalsIgnoreCase(hallId)) {
                    // Replace with new info, keep existing dates
                    line = hallId + "|" + hallType + "|" + capacity + "|" + rate + "|" + parts[4] + "|" + parts[5];
                }
                updated.add(line);
            }
            utils.FileManager.overwriteFile("halls.txt", updated);
            JOptionPane.showMessageDialog(null, "Hall information updated!");
            dispose();
            if (parent != null) parent.reloadTable.run();
        });
    }
}
