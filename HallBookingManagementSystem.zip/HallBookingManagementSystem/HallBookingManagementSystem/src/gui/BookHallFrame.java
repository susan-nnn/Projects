package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.UUID;
import utils.FileManager;

/**
 * BookHallFrame allows the customer to view available halls and book one.
 */
public class BookHallFrame extends JFrame {

    public BookHallFrame(String customerId, String customerName) {
        setTitle("Book a Hall");
        setSize(600, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel setup
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JLabel title = new JLabel("Select a Hall to Book", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        // Table for available halls
        String[] columns = {"Hall ID", "Type", "Capacity", "Rate", "Available Dates"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable hallTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(hallTable);
        panel.add(tableScrollPane, BorderLayout.CENTER);

        // Load available halls from file
        List<String> halls = FileManager.readFile("halls.txt");
        for (String line : halls) {
            String[] data = line.split("\\|");
            if (data.length >= 5 && !data[4].trim().isEmpty()) {
                tableModel.addRow(new Object[]{data[0], data[1], data[2], data[3], data[4]});
            }
        }

        // Booking input fields
        JPanel bookPanel = new JPanel();
        JTextField dateField = new JTextField(10);
        JTextField hoursField = new JTextField(5);
        JTextField attendeesField = new JTextField(5);
        JLabel priceLabel = new JLabel("Price per hour: -");
        JButton bookBtn = new JButton("Book Selected Hall");
        bookPanel.add(new JLabel("Enter Date (MM/dd/yyyy):"));
        bookPanel.add(dateField);
        bookPanel.add(new JLabel("Hours:"));
        bookPanel.add(hoursField);
        bookPanel.add(new JLabel("Attendees:"));
        bookPanel.add(attendeesField);
        bookPanel.add(priceLabel);
        bookPanel.add(bookBtn);
        panel.add(bookPanel, BorderLayout.SOUTH);

        // Update price label on hall selection
        hallTable.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            @Override
            public void valueChanged(javax.swing.event.ListSelectionEvent e) {
                int row = hallTable.getSelectedRow();
                if (row >= 0) {
                    String type = (String) tableModel.getValueAt(row, 1);
                    double price = 0;
                    if (type.equalsIgnoreCase("Auditorium")) price = 300;
                    else if (type.equalsIgnoreCase("Banquet Hall")) price = 100;
                    else if (type.equalsIgnoreCase("Meeting Room")) price = 50;
                    priceLabel.setText("Price per hour: RM " + String.format("%.2f", price));
                } else {
                    priceLabel.setText("Price per hour: -");
                }
            }
        });

        // Book button action
        bookBtn.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
            int selectedRow = hallTable.getSelectedRow();
            String date = dateField.getText().trim();
            String hoursStr = hoursField.getText().trim();

            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Please select a hall.");
                return;
            }
            if (date.isEmpty() || hoursStr.isEmpty()) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Please enter both date and hours.");
                return;
            }
            if (!date.matches("\\d{2}/\\d{2}/\\d{4}")) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Date must be in MM/dd/yyyy format.");
                return;
            }
            int hours;
            try {
                hours = Integer.parseInt(hoursStr);
                if (hours < 1 || hours > 50) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Hours must be a number between 1 and 50.");
                return;
            }
            int attendees;
            try {
                attendees = Integer.parseInt(attendeesField.getText().trim());
                if (attendees < 1) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Attendees must be a positive number.");
                return;
            }

            // Fetch selected hall details
            String hallId = (String) tableModel.getValueAt(selectedRow, 0);
            String hallType = (String) tableModel.getValueAt(selectedRow, 1);
            String capacityStr = (String) tableModel.getValueAt(selectedRow, 2);
            int capacity = 0;
            try {
                capacity = Integer.parseInt(capacityStr.trim());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Invalid capacity for selected hall.");
                return;
            }
            if (attendees > capacity) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Attendees exceed hall capacity (" + capacity + ").");
                return;
            }
            String availableDates = (String) tableModel.getValueAt(selectedRow, 4);
            boolean dateAvailable = false;
            String inputDate = date.trim();
            for (String avail : availableDates.split(",")) {
                String availTrimmed = avail.trim();
                System.out.println("[DEBUG] Comparing inputDate: '" + inputDate + "' with avail: '" + availTrimmed + "'");
                if (availTrimmed.equals(inputDate)) {
                    dateAvailable = true;
                    break;
                }
            }
            if (!dateAvailable) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Selected date is not available for this hall. Please choose from: " + availableDates);
                return;
            }
            String rateStr = (String) tableModel.getValueAt(selectedRow, 3);
            double rate = 0;
            try {
                rate = Double.parseDouble(rateStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Invalid rate for selected hall.");
                return;
            }
            double total = rate * hours;

            // Confirm booking
            int confirm = JOptionPane.showConfirmDialog(BookHallFrame.this,
                "Hall ID: " + hallId + "\n" +
                "Hall Type: " + hallType + "\n" +
                "Date: " + date + "\n" +
                "Hours: " + hours + "\n" +
                "Attendees: " + attendees + "\n" +
                "Rate: RM " + rate + "/hr\n" +
                "Total: RM " + total + "\n\n" +
                "Do you want to proceed with the payment?",
                "Confirm Booking",
                JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // Generate next sequential booking ID (BOK001, BOK002, ...)
                List<String> bookingLines = FileManager.readFile("bookings.txt");
                int maxId = 0;
                for (String l : bookingLines) {
                    String[] d = l.split("\\|");
                    if (d.length > 0 && d[0].startsWith("BOK")) {
                        try {
                            int num = Integer.parseInt(d[0].substring(3));
                            if (num > maxId) maxId = num;
                        } catch (Exception ex) {}
                    }
                }
                String bookingId = String.format("BOK%03d", maxId + 1);

                // Save booking: Format -> ID|CustomerID|HallID|Date|Amount|Status
                String bookingLine = String.join("|", bookingId, customerId, hallId, date, String.valueOf(total), "PENDING");
                FileManager.writeToFile("bookings.txt", bookingLine);

                // Show receipt
                JOptionPane.showMessageDialog(BookHallFrame.this,
                    "Booking Successful!\n\n" +
                    "Booking ID: " + bookingId + "\n" +
                    "Hall Type: " + hallType + "\n" +
                    "Date: " + date + "\n" +
                    "Duration: " + hours + " hours\n" +
                    "Total Paid: RM " + total + "\n" +
                    "Status: PENDING (Manager confirmation required)",
                    "Receipt", JOptionPane.INFORMATION_MESSAGE);

                dispose();  // Close booking window
            } else {
                JOptionPane.showMessageDialog(BookHallFrame.this, "Payment cancelled. Booking not completed.");
            }
        }
    });

        // Add scrollable main panel
        JScrollPane outerScrollPane = new JScrollPane(panel);
        outerScrollPane.setBorder(null);
        outerScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(outerScrollPane);
        setVisible(true);
    }
}
