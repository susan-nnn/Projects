package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import utils.FileManager;

public class ViewMyIssuesFrame extends JFrame {
    public ViewMyIssuesFrame(String customerId) {
        setTitle("My Reported Issues");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columns = {"Issue ID", "Hall ID", "Description", "Status", "Scheduler", "Response"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        List<String> lines = FileManager.readFile("issues.txt");
        for (String line : lines) {
            String[] data = line.split("\\|");
            // Pad to 7 fields for safety
            String[] padded = new String[7];
            for (int i = 0; i < 7; i++) {
                padded[i] = (i < data.length) ? data[i] : "";
            }
            // Only show issues reported by this customer
            if (padded[1].equals(customerId)) {
                model.addRow(new String[]{padded[0], padded[2], padded[3], padded[4], padded[5], padded[6]});
            }
        }
        setVisible(true);
    }
}
