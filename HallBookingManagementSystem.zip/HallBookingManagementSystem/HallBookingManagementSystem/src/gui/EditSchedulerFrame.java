package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import utils.FileManager;

public class EditSchedulerFrame extends JFrame {
    public EditSchedulerFrame(String adminName, String userId, String email, String password, String name, ViewSchedulerStaffFrame parent) {
        setTitle("Edit Scheduler Staff");
        setSize(500, 400);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

        JTextField emailField = new JTextField(email);
        JPasswordField passwordField = new JPasswordField(password);
        JTextField nameField = new JTextField(name);
        JButton saveBtn = new JButton("Save Changes");
        JButton backBtn = new JButton("Back");

        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(saveBtn);
        panel.add(backBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        saveBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String newEmail = emailField.getText().trim();
                String newPassword = new String(passwordField.getPassword());
                String newName = nameField.getText().trim();

                // Validate that no field is empty
if (newEmail.isEmpty() || newPassword.isEmpty() || newName.isEmpty()) {
    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
    return;
}
// Check that password is at least 6 characters
if (newPassword.length() < 6) {
    JOptionPane.showMessageDialog(null, "Password must be at least 6 characters.");
    return;
}
// Basic email format validation
if (!newEmail.contains("@") || !newEmail.contains(".")) {
    JOptionPane.showMessageDialog(null, "Invalid email format.");
    return;
}
// Check for duplicate email except for current user
List<String> users;
try {
    users = FileManager.readFile("users.txt");
} catch (Exception ex) {
    JOptionPane.showMessageDialog(null, "Error reading users file: " + ex.getMessage());
    return;
}
for (String line : users) {
    String[] parts = line.split("\\|");
    if (parts.length >= 5 && parts[2].equalsIgnoreCase(newEmail) && !parts[0].equals(userId)) {
        JOptionPane.showMessageDialog(null, "Email already registered to another user.");
        return;
    }
}
List<String> updated = new ArrayList<>();
for (String line : users) {
    String[] parts = line.split("\\|");
    if (parts.length >= 5 && parts[0].equals(userId)) {
        String newLine = userId + "|Scheduler|" + newEmail + "|" + newPassword + "|" + newName;
        updated.add(newLine);
    } else {
        updated.add(line);
    }
}
                FileManager.overwriteFile("users.txt", updated);
                JOptionPane.showMessageDialog(null, "Scheduler updated successfully!");
                dispose();
                parent.dispose();
                new ViewSchedulerStaffFrame(adminName);
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
} 