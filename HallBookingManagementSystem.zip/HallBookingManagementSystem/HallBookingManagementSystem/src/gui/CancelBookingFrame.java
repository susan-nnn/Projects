package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import utils.FileManager;

public class CancelBookingFrame extends JFrame {

    private JTable bookingTable;
    private DefaultTableModel model;
    private String customerId;

    public CancelBookingFrame(String customerId) {
        this.customerId = customerId;

        setTitle("Cancel Booking");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- Top Table Panel ---
        String[] columns = {"Booking ID", "Hall ID", "Date", "Amount", "Status"};
        model = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        bookingTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        add(scrollPane, BorderLayout.CENTER);

        // --- Bottom Button Panel ---
        JButton cancelBtn = new JButton("Cancel Selected Booking");
        JPanel btnPanel = new JPanel();
        btnPanel.add(cancelBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // --- Load Data into Table ---
        loadBookingsForCustomer(customerId);

        // --- Cancel Booking Action ---
        cancelBtn.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        cancelSelectedBooking();
    }
});

        setVisible(true);
    }

    // Load bookings from file and show only the ones that match the logged-in customer
    private void loadBookingsForCustomer(String customerId) {
        model.setRowCount(0);  // Clear previous data
        List<String> allBookings = FileManager.readFile("bookings.txt");

        for (String line : allBookings) {
            String[] data = line.split("\\|");
            if (data.length == 6 && data[1].equals(customerId)) {
                // Add only bookings that belong to the logged-in customer
                model.addRow(new String[]{data[0], data[2], data[3], data[4], data[5]});
            }
        }
    }

    // Cancel the selected booking and update the file
    private void cancelSelectedBooking() {
        int selectedRow = bookingTable.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking to cancel.");
            return;
        }

        String bookingIdToCancel = (String) model.getValueAt(selectedRow, 0);
        String bookingDateStr = (String) model.getValueAt(selectedRow, 2);
        java.time.LocalDate bookingDate = null;
        boolean dateParseOk = false;
        // Try parsing in both supported formats
        try {
            bookingDate = java.time.LocalDate.parse(bookingDateStr, java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            dateParseOk = true;
        } catch (Exception ex1) {
            try {
                bookingDate = java.time.LocalDate.parse(bookingDateStr, java.time.format.DateTimeFormatter.ofPattern("MM/dd/yyyy"));
                dateParseOk = true;
            } catch (Exception ex2) { }
        }
        if (!dateParseOk) {
            JOptionPane.showMessageDialog(this, "Could not parse booking date. Cancellation not allowed.");
            return;
        }
        java.time.LocalDate today = java.time.LocalDate.now();
        if (!today.isBefore(bookingDate.minusDays(2))) {
            // today is bookingDate - 2 days or later
            JOptionPane.showMessageDialog(this, "You can only cancel a booking at least 3 days before the booking date.");
            return;
        }
        List<String> allBookings = FileManager.readFile("bookings.txt");
        List<String> updated = new ArrayList<>();
        boolean found = false;

        for (String line : allBookings) {
            String[] parts = line.split("\\|");
            if (parts.length == 6) {
                if (parts[0].equals(bookingIdToCancel) && parts[1].equals(customerId)) {
                    found = true;
                    parts[5] = "Cancelled"; // Update status
                    updated.add(String.join("|", parts));
                } else {
                    updated.add(line);
                }
            }
        }

        if (found) {
            FileManager.overwriteFile("bookings.txt", updated);
            JOptionPane.showMessageDialog(this, "Booking cancelled successfully.");
            loadBookingsForCustomer(customerId);
        } else {
            JOptionPane.showMessageDialog(this, "Booking not found or doesn't belong to you.");
        }
    }

    // For testing independently
    public static void main(String[] args) {
        new CancelBookingFrame("CUS001");
    }
}
