package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CustomerDashboard extends JFrame {

    private JButton viewHallsBtn, bookHallBtn, viewBookingsBtn, cancelBookingBtn, raiseIssueBtn, updateProfileBtn, viewMyIssuesBtn;

    public CustomerDashboard(String customerName) {
        setTitle("Welcome " + customerName);
        setSize(600,650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 1, 10, 10));

        viewHallsBtn = new JButton("View Available Halls");
        viewHallsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewHallsFrame();
            }
        });

        // Book Hall Button
        bookHallBtn = new JButton("Book a Hall");
        final String userId = customerName;
        final String[] displayName = {customerName};
        final java.util.List<String> users = utils.FileManager.readFile("users.txt");
        for (String line : users) {
            String[] parts = line.split("\\|");
            if (parts.length >= 5 && parts[0].equals(userId)) {
                displayName[0] = parts[4];
                break;
            }
        }
        bookHallBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new BookHallFrame(userId, displayName[0]);
            }
        });

        viewBookingsBtn = new JButton("View Bookings");
        viewBookingsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewBookingsFrame(userId);
            }
        });

        // Cancel Booking Button
        cancelBookingBtn = new JButton("Cancel Booking");
        cancelBookingBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CancelBookingFrame(userId);
            }
        });

        // View My Issues Button
        viewMyIssuesBtn = new JButton("View My Issues");
        viewMyIssuesBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewMyIssuesFrame(userId);
            }
        });
        panel.add(viewMyIssuesBtn);

        // Raise Issue Button
        raiseIssueBtn = new JButton("Raise an Issue");
        raiseIssueBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RaiseIssueFrame(userId);
            }
        });

        // Update Profile Button
        updateProfileBtn = new JButton("Update Profile");
        updateProfileBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new UpdateProfileFrame(displayName[0]);
            }
        });

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame();
            }
        });

        panel.add(viewHallsBtn);
        panel.add(bookHallBtn);
        panel.add(viewBookingsBtn);
        panel.add(cancelBookingBtn);
        panel.add(raiseIssueBtn);
        panel.add(updateProfileBtn);
        panel.add(logoutBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);

        setVisible(true);
    }
}