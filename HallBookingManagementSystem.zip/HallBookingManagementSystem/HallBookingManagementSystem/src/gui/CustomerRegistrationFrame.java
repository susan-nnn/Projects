package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import utils.FileManager;

public class CustomerRegistrationFrame extends JFrame {
    public CustomerRegistrationFrame() {
        setTitle("Customer Registration");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JPasswordField confirmPasswordField = new JPasswordField();
        JButton registerBtn = new JButton("Register");
        JButton backBtn = new JButton("Back to Login");

        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Confirm Password:"));
        panel.add(confirmPasswordField);
        panel.add(registerBtn);
        panel.add(backBtn);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);
        setVisible(true);

        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }
                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(null, "Passwords do not match.");
                    return;
                }
                if (!email.contains("@") || !email.contains(".")) {
                    JOptionPane.showMessageDialog(null, "Invalid email format.");
                    return;
                }
                // Check for duplicate email
                List<String> users = FileManager.readFile("users.txt");
                for (String line : users) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 3 && parts[2].equalsIgnoreCase(email)) {
                        JOptionPane.showMessageDialog(null, "Email already registered.");
                        return;
                    }
                }
                // Generate sequential customer ID
                int maxId = 0;
                for (String u : users) {
                    String[] p = u.split("\\|");
                    if (p.length > 0 && p[0].startsWith("CUS")) {
                        try {
                            int num = Integer.parseInt(p[0].substring(3).replaceAll("[^0-9]", ""));
                            if (num > maxId) maxId = num;
                        } catch (Exception ex) { }
                    }
                }
                String userId = String.format("CUS%03d", maxId + 1);
                String line = userId + "|Customer|" + email + "|" + password + "|" + name;
                FileManager.writeToFile("users.txt", line);
                JOptionPane.showMessageDialog(null, "Registration successful! You can now login.");
                dispose();
                new LoginFrame();
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame();
            }
        });
    }

    public static void main(String[] args) {
        new CustomerRegistrationFrame();
    }
} 