package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import utils.FileManager;

public class ViewHallsFrame extends JFrame {

    public ViewHallsFrame() {
        setTitle("View Halls");
        setSize(500, 400);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        String[] columnNames = {"Hall ID", "Type", "Capacity", "Rate", "Available Dates"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable hallTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(hallTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        JScrollPane outerScrollPane = new JScrollPane(panel);
        outerScrollPane.setBorder(null);
        outerScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(outerScrollPane, BorderLayout.CENTER);

        // Read from halls.txt with debug print and error handling
        String filePath = new java.io.File("halls.txt").getAbsolutePath();
        // Reading halls.txt from the working directory. If not found, an error dialog will be shown.
        List<String> lines = FileManager.readFile("halls.txt");
        if (lines == null || lines.isEmpty()) {
            JOptionPane.showMessageDialog(this, "halls.txt not found or is empty!\nPath: " + filePath, "File Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (String line : lines) {
                String[] data = line.split("\\|"); 
                if (data.length >=5) {
                    tableModel.addRow(data);
                }
            }
        }
        setVisible(true);
    }


}