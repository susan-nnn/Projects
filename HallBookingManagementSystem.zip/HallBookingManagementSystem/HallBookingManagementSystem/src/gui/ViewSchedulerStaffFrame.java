package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import utils.FileManager;

public class ViewSchedulerStaffFrame extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField searchField;

    public ViewSchedulerStaffFrame(String adminName) {
        setTitle("Scheduler Staff");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Search Panel ---
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search (Name or Email): "));
        searchField = new JTextField(20);
        searchPanel.add(searchField);

        // --- Table ---
        String[] columnNames = {"UserID", "Email", "Password", "Name"};
        model = new DefaultTableModel(columnNames, 0) {
            // Make table cells not editable directly
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // --- Buttons ---
        JButton editBtn = new JButton("Edit Selected");
        JButton deleteBtn = new JButton("Delete Selected");
        JButton backBtn = new JButton("Back");

        JPanel btnPanel = new JPanel();
        btnPanel.add(editBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(backBtn);

        // --- Layout ---
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(searchPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        JScrollPane scrollPaneMain = new JScrollPane(mainPanel);
        scrollPaneMain.setBorder(null);
        scrollPaneMain.getVerticalScrollBar().setUnitIncrement(16);

        setLayout(new BorderLayout());
        add(scrollPaneMain, BorderLayout.CENTER);

        // --- Load Data ---
        loadTable("");

        // --- Search Functionality ---
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String text = searchField.getText().trim();
                loadTable(text);
            }
        });

        // --- Edit Button ---
        editBtn.addActionListener(_ -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a scheduler staff to edit.");
                return;
            }
            String userId = (String) model.getValueAt(row, 0);
            String email = (String) model.getValueAt(row, 1);
            String password = (String) table.getModel().getValueAt(row, 2); // model has "*****", so get real password from file
            String name = (String) model.getValueAt(row, 3);

            // Find real password from file for editing
            List<String> users = FileManager.readFile("users.txt");
            for (String line : users) {
                String[] parts = line.split("\\|");
                if (parts.length >= 5 && parts[0].equals(userId)) {
                    password = parts[3];
                    break;
                }
            }
            // Open Edit Frame
            new EditSchedulerFrame(adminName, userId, email, password, name, this);
        });

        // --- Delete Button ---
        deleteBtn.addActionListener(_ -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a scheduler staff to delete.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this scheduler staff?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            String userId = (String) model.getValueAt(row, 0);

            // Read users file with error handling
            List<String> users;
            try {
                users = FileManager.readFile("users.txt");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error reading users file: " + ex.getMessage());
                return;
            }
            List<String> updated = new ArrayList<>();
            for (String line : users) {
                String[] parts = line.split("\\|");
                if (parts.length >= 5 && parts[0].equals(userId) && parts[1].equalsIgnoreCase("Scheduler")) {
                    // skip this line (delete)
                    continue;
                }
                updated.add(line);
            }
            try {
                FileManager.overwriteFile("users.txt", updated);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error updating users file: " + ex.getMessage());
                return;
            }
            JOptionPane.showMessageDialog(this, "Scheduler staff deleted.");
            loadTable(searchField.getText().trim());
        });

        // --- Back Button ---
        backBtn.addActionListener(_ -> {
            dispose();
            new AdminDashboard(adminName);
        });

        setVisible(true);
    }

    // Helper function to load table data, with optional filter
    private void loadTable(String filter) {
        model.setRowCount(0); // clear table
        List<String> users = FileManager.readFile("users.txt");
        for (String line : users) {
            if (line.startsWith("UserID|")) continue;
            String[] parts = line.split("\\|");
            if (parts.length >= 5 && parts[1].equalsIgnoreCase("Scheduler")) {
                String userId = parts[0];
                String email = parts[2];
                String password = "*****"; // mask password
                String name = parts[4];
                if (filter.isEmpty() || email.toLowerCase().contains(filter.toLowerCase()) || name.toLowerCase().contains(filter.toLowerCase())) {
                    model.addRow(new String[]{userId, email, password, name});
                }
            }
        }
    }

    public static void main(String[] args) {
        new ViewSchedulerStaffFrame("Admin");
    }
}