package gui;
import java.io.File;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import utils.FileManager;

public class LoginFrame extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JComboBox<String> roleBox;

    public LoginFrame() {
        setTitle("Login");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10));

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        String[] roles = {"Customer", "Scheduler", "Manager", "Admin"};
        roleBox = new JComboBox<>(roles);
        panel.add(new JLabel("Role:"));
        panel.add(roleBox);

        loginButton = new JButton("Login");
        registerButton = new JButton("Register as Customer");
        panel.add(new JLabel("")); 
        panel.add(loginButton);
        panel.add(new JLabel(""));
        panel.add(registerButton);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword());
                String selectedRole = (String) roleBox.getSelectedItem();

                if (email.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both email and password.");
                    utils.Logger.log("Login attempt failed: Empty email or password");
                    return;
                }
                if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                    utils.Logger.log("Login attempt failed: Invalid email format: " + email);
                    return;
                }

                final String ADMIN_EMAIL = "admin@admin.com";
                final String ADMIN_PASSWORD = "admin123";
                final String ADMIN_NAME = "Admin";

                if (selectedRole.equalsIgnoreCase("Administrator") || selectedRole.equalsIgnoreCase("Admin")) {
                    if (email.equalsIgnoreCase(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                        dispose();
                        String welcomeMsg = "Welcome, " + selectedRole + "!";
                        JOptionPane.showMessageDialog(null, welcomeMsg);
                        utils.Logger.log("Login successful for user: " + email + " as " + selectedRole);
                        new AdminDashboard(ADMIN_NAME);
                        return;
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid admin credentials.");
                        utils.Logger.log("Login attempt failed: Invalid admin credentials");
                        return;
                    }
                }

                String filePath = new File("").getAbsolutePath() + File.separator + "users.txt";
                List<String> users = FileManager.readFile(filePath);

                boolean found = false;
                for (String line : users) {
                    if (line.startsWith("UserID|")) continue;
                    String[] parts = line.split("\\|");
                    if (parts.length >= 5 && parts[2].equalsIgnoreCase(email) && parts[3].equals(password) && parts[1].equalsIgnoreCase(selectedRole)) {
                        found = true;
                        String role = parts[1];
                        String userId = parts[0];
                        
                        dispose();
                        if (role.equalsIgnoreCase("Customer")) {
                            new CustomerDashboard(userId);
                        } else if (role.equalsIgnoreCase("Scheduler")) {
                            new SchedulerDashboard(userId);
                        } else if (role.equalsIgnoreCase("Manager")) {
                            new ManagerDashboard();
                        } else {
                            JOptionPane.showMessageDialog(null, "Unknown role: " + role);
                        }
                        return;
                    }
                }
                if (!found) {
                    JOptionPane.showMessageDialog(null, "Invalid credentials or role. Try again.");
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new CustomerRegistrationFrame();
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginFrame();
    }
}