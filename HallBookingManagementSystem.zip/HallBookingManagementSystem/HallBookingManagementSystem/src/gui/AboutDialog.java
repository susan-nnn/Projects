package gui;

import javax.swing.*;
import java.awt.*;

public class AboutDialog extends JDialog {
    public AboutDialog(JFrame parent) {
        super(parent, "About Hall Booking System", true);
        setSize(400, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JTextArea aboutText = new JTextArea();
        aboutText.setEditable(false);
        aboutText.setText(
                "Hall Booking Management System\n" +
                "\n" +
                "Developed by: [Your Name]\n" +
                "\n" +
                "Features:\n" +
                "- Book, view, and cancel hall bookings\n" +
                "- Role-based access (Customer, Scheduler, Manager, Admin)\n" +
                "- Simple file-based data storage\n" +
                "\n" +
                "Instructions:\n" +
                "1. Login or register as a customer.\n" +
                "2. Book available halls, view your bookings.\n" +
                "3. Contact admin for more access.\n" +
                "\n" +
                "(c) 2025 Asia Pacific University"
        );
        add(new JScrollPane(aboutText), BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispose();
            }
        });
        JPanel btnPanel = new JPanel();
        btnPanel.add(closeBtn);
        add(btnPanel, BorderLayout.SOUTH);
    }
}
