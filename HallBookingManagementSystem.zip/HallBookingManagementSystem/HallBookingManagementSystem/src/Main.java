
// Main.java - Entry point for Hall Booking Management System

public class Main {
    public static void main(String[] args) {
        // Check and create default data files if missing
        String[] files = {"users.txt", "halls.txt", "bookings.txt", "issues.txt"};
        String[] headers = {
            "userId|name|email|password|role|active",
            "hallId|type|capacity|rate|availableDates|maintenanceDates",
            "bookingId|userId|hallId|date|total|status",
            "issueId|reporterId|title|description|status|assignedTo|timestamp"
        };
        for (int i = 0; i < files.length; i++) {
            java.io.File f = new java.io.File(files[i]);
            if (!f.exists()) {
                try {
                    java.io.FileWriter w = new java.io.FileWriter(f);
                    w.write(headers[i] + System.lineSeparator());
                    w.close();
                } catch (java.io.IOException ex) {
                    System.err.println("Error creating file: " + files[i] + " - " + ex.getMessage());
                }
            }
        }
        // Launch the Login Frame as the entry point
        gui.LoginFrame.main(args);
    }
}
