package model;

import java.util.ArrayList;

public class Hall implements Bookable {
    private String hallId;
    private String hallType;
    private int capacity;
    private double bookingRate;
    private ArrayList<String> availabilityDates; 
    private ArrayList<String> maintenanceSchedule; 

    public Hall(String hallId, String hallType, int capacity, double bookingRate) {
        this.hallId = hallId;
        this.hallType = hallType;
        this.capacity = capacity;
        this.bookingRate = bookingRate;
        this.availabilityDates = new ArrayList<>();
        this.maintenanceSchedule = new ArrayList<>();
    }

    public void addAvailability(String dateTime) {
        availabilityDates.add(dateTime);
    }

    public void scheduleMaintenance(String dateTime) {
        maintenanceSchedule.add(dateTime);
    }

    public boolean isAvailable(String dateTime) {
        return availabilityDates.contains(dateTime) && !maintenanceSchedule.contains(dateTime);
    }

    
    public String getHallId() { return hallId; }
    public String getHallType() { return hallType; }
    public int getCapacity() { return capacity; }
    public double getBookingRate() { return bookingRate; }
    public ArrayList<String> getAvailabilityDates() { return availabilityDates; }
    public ArrayList<String> getMaintenanceSchedule() { return maintenanceSchedule; }
}