package model;

public interface Bookable {
    boolean isAvailable(String dateTime);
    double getBookingRate();
    String getHallId();
}
