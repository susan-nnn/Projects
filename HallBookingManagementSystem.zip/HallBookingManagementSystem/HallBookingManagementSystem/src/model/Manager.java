package model;

public class Manager extends User implements Reportable {
    public Manager(String userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    @Override
    public void login() {
        // Manager-specific login logic
    }

    @Override
    public void logout() {
        // Manager-specific logout logic
    }

    @Override
    public void viewDashboard() {
        // Manager dashboard logic (polymorphism example)
        System.out.println("Welcome to the Manager Dashboard, " + getName() + "!");
    }

    public void generateReport() {
        // Report generation logic
    }
}
