package model;

public class Admin extends User {
    public Admin(String userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    @Override
    public void login() {
        // Admin-specific login logic
    }

    @Override
    public void logout() {
        // Admin-specific logout logic
    }

    @Override
    public void viewDashboard() {
        // Admin dashboard logic (polymorphism example)
        System.out.println("Welcome to the Admin Dashboard, " + getName() + "!");
    }

    public void manageUsers() {
        // User management logic
    }
}
