package model;

public class Booking {
    private String bookingId;
    private String hallId;
    private String customerId;
    private String dateTime; 
    private double totalAmount;
    private String status; 

    public Booking(String bookingId, String hallId, String customerId, String dateTime, double totalAmount, String status) {
        this.bookingId = bookingId;
        this.hallId = hallId;
        this.customerId = customerId;
        this.dateTime = dateTime;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    public double calculateCost(double baseRate, int durationHours) {
        return baseRate * durationHours;
    }

    public String generateReceipt() {
        return "Receipt:\n" +
               "Booking ID: " + bookingId + "\n" +
               "Hall ID: " + hallId + "\n" +
               "Customer ID: " + customerId + "\n" +
               "Date & Time: " + dateTime + "\n" +
               "Amount Paid: RM" + totalAmount + "\n" +
               "Status: " + status + "\n";
    }

  
    public String getBookingId() { return bookingId; }
    public String getHallId() { return hallId; }
    public String getCustomerId() { return customerId; }
    public String getDateTime() { return dateTime; }
    public double getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }
}