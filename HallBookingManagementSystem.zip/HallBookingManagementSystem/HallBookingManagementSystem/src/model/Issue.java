package model;

public class Issue {
    private String issueId;
    private String customerId;
    private String hallId;
    private String description;
    private String status;
    private String assignedSchedulerId;

    public Issue(String issueId, String customerId, String hallId, String description) {
        this.issueId = issueId;
        this.customerId = customerId;
        this.hallId = hallId;
        this.description = description;
        this.status = "Pending";
        this.assignedSchedulerId = "";
    }

    public void updateStatus(String newStatus) {
        this.status = newStatus;
    }

    public void assignScheduler(String schedulerId) {
        this.assignedSchedulerId = schedulerId;
    }

    // Getters
    public String getIssueId() { return issueId; }
    public String getCustomerId() { return customerId; }
    public String getHallId() { return hallId; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }
    public String getAssignedSchedulerId() { return assignedSchedulerId; }
}