package model;

public class Scheduler extends User {

    @Override
    public void viewDashboard() {
        // Scheduler dashboard logic (polymorphism example)
        // viewDashboard logic for Scheduler (polymorphism demonstration).
    }

    public Scheduler(String userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    @Override
    public void login() {}

    @Override
    public void logout() {}

    public void addHall(String hallName) {}

    public void editHall(String hallId) {}

    public void deleteHall(String hallId) {}

    public void setAvailability(String hallId, String dateTime) {}

    public void scheduleMaintenance(String hallId, String dateTime, String remarks) {}
}