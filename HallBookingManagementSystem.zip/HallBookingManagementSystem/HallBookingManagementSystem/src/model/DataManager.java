package model;

import java.io.*;
import java.util.*;

public class DataManager {
    // Encapsulate all file reading
    public static List<String> readFile(String filename) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + filename + " - " + e.getMessage());
        }
        return lines;
    }

    // Encapsulate all file writing (append)
    public static void writeToFile(String filename, String content) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(content);
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Error writing to file: " + filename + " - " + e.getMessage());
        }
    }

    // Encapsulate file overwrite
    public static void overwriteFile(String filename, List<String> contents) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, false))) {
            for (String line : contents) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error overwriting file: " + filename + " - " + e.getMessage());
        }
    }
}
