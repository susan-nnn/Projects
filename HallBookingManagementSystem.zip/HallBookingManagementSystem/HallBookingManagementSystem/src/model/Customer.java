package model;

public class Customer extends User {

    @Override
    public void viewDashboard() {
        // Customer dashboard logic (polymorphism example)
        System.out.println("Welcome to the Customer Dashboard, " + getName() + "!");
    }

    public Customer(String userId, String name, String email, String password) {
        super(userId, name, email, password);
    }

    @Override
    public void login() {}

    @Override
    public void logout() {}

    public void bookHall(String hallId, String dateTime) {
        // Simulated logic: check if booking exists (normally, would check bookings file or DB)
        boolean conflict = false; // Replace with real check
        try {
            // Simulate conflict detection
            if (conflict) {
                throw new BookingConflictException("Booking conflict for hall " + hallId + " at " + dateTime);
            }
            // Proceed with booking (call DataManager, etc.)
            System.out.println("Hall booked successfully: " + hallId + " at " + dateTime);
        } catch (BookingConflictException e) {
            System.err.println("Booking failed: " + e.getMessage());
        }
    }

    public void cancelBooking(String bookingId) {}

    public void raiseIssue(String description) {}
}