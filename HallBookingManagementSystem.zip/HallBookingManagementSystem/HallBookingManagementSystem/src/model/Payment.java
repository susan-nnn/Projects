package model;

import java.time.LocalDateTime;

public class Payment {
    private String paymentId;
    private String bookingId;
    private double amountPaid;
    private LocalDateTime paymentDate;

    public Payment(String paymentId, String bookingId, double amountPaid) {
        this.paymentId = paymentId;
        this.bookingId = bookingId;
        this.amountPaid = amountPaid;
        this.paymentDate = LocalDateTime.now(); 
    }

    public String printReceipt() {
        return "Payment Receipt:\n" +
               "Payment ID: " + paymentId + "\n" +
               "Booking ID: " + bookingId + "\n" +
               "Amount Paid: $" + amountPaid + "\n" +
               "Payment Date: " + paymentDate.toString() + "\n";
    }

    // Getters
    public String getPaymentId() { return paymentId; }
    public String getBookingId() { return bookingId; }
    public double getAmountPaid() { return amountPaid; }
    public LocalDateTime getPaymentDate() { return paymentDate; }
}