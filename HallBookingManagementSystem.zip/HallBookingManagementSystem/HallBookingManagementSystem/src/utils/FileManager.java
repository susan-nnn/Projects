package utils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

  
    public static List<String> readFile(String fileName) {
        List<String> data = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) { isFirstLine = false; continue; } // skip header
                data.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + fileName);
        }
        return data;
    }

    
    public static void writeToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(content);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + fileName);
        }
    }

   
    public static void overwriteFile(String fileName, List<String> contents) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write header if overwriting issues.txt or bookings.txt
            if (fileName.equals("issues.txt")) {
                writer.write("Issue ID|Customer ID|Hall ID|Description|Status|Scheduler|Response");
                writer.newLine();
            } else if (fileName.equals("bookings.txt")) {
                writer.write("Booking ID|Customer ID|Hall ID|Date|Amount|Status");
                writer.newLine();
            }
            for (String line : contents) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error overwriting file: " + fileName);
        }
    }
}